/* 
 * CSC533 HomeWork 4
 * Group Member: Xudong Weng, Laiyong Mu
 *
 * Operations:
 * 	arrow up, down, left, right: select the panel. selected panel showing with white frame.
 *  +: show another row of leaf-plates, maximum is 4 levels.
 * 	-: kill the lowest row.
 * 	r: the slected plate rotate clockwise in larger steps.
 * 	R: the slected plate rotate counterclockwise in larger steps.
 * 	c: the slected plate rotating at some random constant angular speed (0.5 - 2.5, step size 0.02).
 * 	P: pause/play button for the rotation.
 * 	1: press number one close the window.
 *
 * Accompanied programs [raster.cxx, raster.h, raster-jpeg.cxx] 
 * are from "Paintdemo" provided by the instructor.
 */

#include <stdio.h>
#include <stdlib.h>
#include <GL/glu.h>       
#include <GL/glut.h> 
#include <math.h>     
#include "raster.h"

/* Function Prototypes and Global Variables */

extern ByteRaster *read_jpeg_image(const char *filename);
static ByteRaster *gimage;            // pixel buffer for jpeg picture
void ReadInFile(int imagNum);         // read jpeg file to buffer
static char *infile[15];              // names of the pictures' file
void display();                       // draw in main window through gl functions
static void key_CB(unsigned char key, int x, int y);     // Called on key press 
static void SpecialKey_CB(int key, int x, int y);    // Called on special key press

GLuint texture[15];              // texture ID for different plates 
GLfloat angleR[15];              // rotating angle at each frame of different plates
GLfloat speedR[15];              // rotating speed of different plates
bool pauseLabel = false;         // pause/play label
GLint selected = 0;              // selected plate id
GLint maxLevel = 3;              // current maximum level being shown, from 0 to 3
GLfloat gap = 0.01;              // gap size between plates

int winMain;

/* initiation */
void initGL() {
	glClearColor(0.5f, 0.5f, 0.5f, 0.0f); // Set background color to black and opaque
	glClearDepth(1.0f);                   // Set background depth to farthest
	glEnable(GL_DEPTH_TEST);   // Enable depth testing for z-culling
	glDepthFunc(GL_LEQUAL);    // Set the type of depth-test
	glShadeModel(GL_SMOOTH);   // Enable smooth shading
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);  // Nice perspective corrections
	
	glEnable(GL_LIGHTING);          // Enable lighting
	GLfloat ambientColor[] = {1.0f, 1.0f, 1.0f, 1.0f}; 
        glLightModelfv(GL_LIGHT_MODEL_AMBIENT, ambientColor);
	glEnable(GL_LIGHT0);            // set up a direct light source
	glLightModeli(GL_LIGHT_MODEL_TWO_SIDE, GL_TRUE);  //Enable lighting on both sides
	GLfloat lightColor0[] = {1.0f, 1.0f, 1.0f, 1.0f};
	GLfloat lightpos[] = {0.5, 1.0, 3.0, 0.};
	glLightfv(GL_LIGHT0, GL_DIFFUSE, lightColor0);
	glLightfv(GL_LIGHT0, GL_POSITION, lightpos);
}

/* generate the texture buffer from image buffer for GL mode */
void generateTexturesBuffer(int k){
	// Create texture 
	glGenTextures(k+1, &texture[k]);
	glBindTexture(GL_TEXTURE_2D, texture[k]);     // binding the 2D texture
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexImage2D(GL_TEXTURE_2D, 0, 3, gimage->width(), gimage->height(),
            0, GL_RGB, GL_UNSIGNED_BYTE, gimage->data);
}

/* load textures  */
void LoadGLTextures(int k) {
	// load Textures from buffer
    glBindTexture(GL_TEXTURE_2D, texture[k]);     // binding the 2D texture
    glEnable(GL_TEXTURE_2D);                      // Enable Texture Mapping
    glShadeModel(GL_SMOOTH);                      // Enable Smooth Shading
	glClearColor(1.0f, 1.0f, 1.0f, 1.0f);         // white Background
    glClearDepth(1.0f);                           // Depth Buffer Setup
    glEnable(GL_DEPTH_TEST);                      // Enables Depth Testing
    glDepthFunc(GL_LEQUAL);                       // The Type Of Depth Testing To Do
    glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);          // Really Nice Perspective Calculations
} 

/* function for calculate panel position */
GLfloat *calXY(GLint plateNum, GLint levelNum){
	GLfloat XYmin[2];
	GLfloat *temp;
	
	// the cordinates of root plate (plateNum 0)
	if (plateNum < 1) {
		XYmin[0] = -0.5;
		XYmin[1] = 1.0;
	}
	else {
		if (plateNum%2 == 1) {  // left child plate 
			temp = calXY((plateNum-1)/2, levelNum - 1);
			XYmin[0] = temp[0];
			XYmin[1] = temp[1] - 2/exp2(levelNum+1);
		}
		else {  // right child plate
			temp = calXY(plateNum/2 - 1, levelNum - 1);
			XYmin[0] = temp[0] + 4/exp2(levelNum+1);
			XYmin[1] = temp[1] - 2/exp2(levelNum+1);
		}
	}
	return XYmin;
}

// draw plates in recursive way
void plates(GLint plateNum, GLint levelNum)
{
	GLfloat *xymin = calXY(plateNum, levelNum);
	GLfloat xmin = xymin[0];
	GLfloat ymin = xymin[1];
	GLfloat xmax = xymin[0] + 2/exp2(levelNum);
	GLfloat ymax = xymin[1] + 1/exp2(levelNum);
		
	glPushMatrix();
	glTranslatef((xmax - 1/exp2(levelNum)), 0.0f, 0.0f);
	glRotatef(angleR[plateNum], 0.0f, 1.0f, 0.0f);
	glTranslatef((1/exp2(levelNum) - xmax), 0.0f, 0.0f);
	LoadGLTextures(plateNum);
	glBegin(GL_QUADS);
		glNormal3d(0, 0, 1); 
		glTexCoord2f(1.0f, 0.0f); glVertex3f(xmax-gap, ymax-gap, 0.0);  //right top
		glTexCoord2f(0.0f, 0.0f); glVertex3f(xmin+gap, ymax-gap, 0.0);  //left top
		glTexCoord2f(0.0f, 1.0f); glVertex3f(xmin+gap, ymin+gap, 0.0);  //left bottom
		glTexCoord2f(1.0f, 1.0f); glVertex3f(xmax-gap, ymin+gap, 0.0);  //right bottom
	glEnd();
	
	// draw outline of the selected plate
	if (selected == plateNum){
		glDisable(GL_TEXTURE_2D);
		glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
		glColor3f(1.0f, 0.0f, 1.0f);
		glLineWidth(4.0f);
		glBegin(GL_QUADS);
			glVertex3f(xmax, ymax, 0.0);  //right top
			glVertex3f(xmin, ymax, 0.0);  //left top
			glVertex3f(xmin, ymin, 0.0);  //left bottom
			glVertex3f(xmax, ymin, 0.0);  //right bottom
		glEnd();
		glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
		glEnable(GL_TEXTURE_2D);
	}
	
	// draw the child plates
	if (levelNum < maxLevel) {
		plates(2*plateNum + 1, levelNum + 1);
		plates(2*(plateNum + 1), levelNum + 1);
	}
	glPopMatrix();
}

void display (void) 
{
	glClearColor (0.0,0.0,0.0,1.0);
	glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);    // Clear screen and Z-buffer
	glMatrixMode(GL_MODELVIEW);  
	glLoadIdentity();  
	gluLookAt(0.5, 1.0, 3.0, 0.5, 1.0, 2.0, 0.0, 1.0, 0.0);
	glEnable(GL_TEXTURE_2D);
	plates(0, 0);
	glutSwapBuffers();
	
	int i;
	if (!pauseLabel){
		for (i = 0; i < 15; i++)
		angleR[i] += speedR[i];
	}
}

void reshape (int w, int h) {
	glViewport (0, 0, 800, 800);
	glMatrixMode (GL_PROJECTION);
	glLoadIdentity ();
	gluPerspective (45.0, 1, 1.0, 100.0);
	glMatrixMode (GL_MODELVIEW);
}	


/* Function is called on a key press */
static void key_CB(unsigned char key, int x, int y) 
{
    switch (key)
	{	
		// show one more level
		case '+':
			if (maxLevel < 3)
				maxLevel++;
			break;
		
		// delete the lowest level
		case '-':
			if (maxLevel > 0)
				maxLevel--;
			break;
			
		// rotate colociwise and increase the speed
		case 'r':
			if (speedR[selected] >= 0)
				speedR[selected] += 2;
			else
				speedR[selected] = -speedR[selected];
			break;
		
		// rotate countercolockwise and increase the speed
		case 'R':
			if (speedR[selected] <= 0)
				speedR[selected] -= 2;
			else
				speedR[selected] = -speedR[selected];
			break;
			
		// set a random rotation speed for the selected plate (0.5-2.5)
		case 'c':
			speedR[selected] = rand()%100/50 + 0.5;
			break;
			
		// pause/restart the rotation
		case 'p':
			if (pauseLabel == true)
				pauseLabel = false;
			else
				pauseLabel = true;
			break;
			
		// exit
		case '1':
			exit(0);
			break;
		
		default: 
			break;
	}
	glutPostRedisplay (); // state has changed: tell GLUT to redraw
}

static void SpecialKey_CB(int key, int x, int y)
{
	// use arrow keys to select plate
	switch (key)
	{
		case GLUT_KEY_LEFT:
			if (selected > 0)
				selected -= 1;
			break;
		case GLUT_KEY_RIGHT:
			if (selected < 14)
				selected += 1;
			break;
		case GLUT_KEY_UP:
			if (selected % 2 == 0 && selected != 0)
				selected = selected/2 - 1;
			else if (selected % 2 != 0)
				selected = (selected-1)/2;
			else
				selected = selected;
			break;
		case GLUT_KEY_DOWN:
			if ((selected*2 + 1) < 15)
				selected = selected*2 + 1;
			break;
		default:
			break;
	}
	glutPostRedisplay ();
}

/* main() function */
int main(int argc, char* argv[])
{   	
	glutInit(&argc,argv);                         // Initialize GLUT and process user parameters
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA | GLUT_DEPTH);  // Request double buffered true color window with Z-buffer
	glutInitWindowSize(800, 800);                 // Set the window's initial width & height
	glutInitWindowPosition(100, 100);                // Position the window's initial top-left corner
	winMain = glutCreateWindow("Universe Mobile");   // Create window

	GLint i;
	for (i=0; i<15; i++){
		ReadInFile(i);
		generateTexturesBuffer(i);  // generate texture buffer for each plate
	}
	
	// initiate rotate angle and speed
	for (i=0; i<15; i++){
		angleR[i] = 0.0;
		speedR[i] = 0.0;
	}
		
	//glutPassiveMotionFunc(Mouse_CB);
	glutDisplayFunc(display);
	glutIdleFunc(display);
	glutReshapeFunc(reshape);
	glutKeyboardFunc(key_CB);
	glutSpecialFunc(SpecialKey_CB);
	
	initGL();                       // OpenGL initialization
	glutMainLoop();
	return 0;
}

// Read in all the jpg file to image array
void ReadInFile(int imagNum){
	infile[0] = "t01.jpg";
	infile[1] = "t02.jpg";
	infile[2] = "t03.jpg";
	infile[3] = "t04.jpg";
	infile[4] = "t05.jpg";
	infile[5] = "t06.jpg";
	infile[6] = "t07.jpg";
	infile[7] = "t08.jpg";
	infile[8] = "t09.jpg";
	infile[9] = "t10.jpg";
	infile[10] = "t11.jpg";
	infile[11] = "t12.jpg";
	infile[12] = "t13.jpg";
	infile[13] = "t14.jpg";
	infile[14] = "t15.jpg";
	
	gimage = read_jpeg_image(infile[imagNum]);
}

