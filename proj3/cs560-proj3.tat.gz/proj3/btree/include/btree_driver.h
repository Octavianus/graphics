
#include "btfile.h"
#include "index.h"

class BTreeTest {

public:

Status runTests();

 void test1();
 void test2();
 void test3();
 void test4();
 void menu();
 void PrintInfo(BTreeFile* btf);
 void test_scan(IndexFileScan* scan);

};



