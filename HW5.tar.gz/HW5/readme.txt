********************
CSC533 HomeWork 5
Group Member: Laiyong Mu, Xudong Weng
********************

1. Use shader programing to generate a cylinder-shape snake body which reflects the backgroud behind the viewer. 

2. Our snake body reflects a "mountain-stellar sky" background. The white points indicate the control points that are used to produce the B Spline curve (the spine of the snake body).

3. Basic Operations:
	'esc': close the window.
	'p': pause/restart the motion.
4. The "parameters.txt" file includes parameters used in the program:
	(1) row 1 - 7 are the coordinates of 7 control points at the beginning of the motion phase
	(2) row 8 - 14 are the coordinates of 7 control points at the end of the motion phase
	(3) row 15 is the radius of the snake body cross section
	(4) row 16 is the period of the motion cycle

5. <main.cxx>: main program of the project

6. <scence.h>: inclucding importanct functions to generate the cyclinder and environment cubemap.

7. <data/shader.vp, data/shader.fp>: vertex shader and fragment shader

8. Accompanied programs [raster.cxx, raster.h, raster-jpeg.cxx] are from "Paintdemo" provided by the instructor.

9. Part of the programs [main.cxx, scence.h, shader.cxx] are modified from a example used by the instructor during the class. A copyright disclaimer is included in the programs and also as below:

****************************************
 * Copyright (C) 2010 Josh A. Beam
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *   1. Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *   2. Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

