 * CSC533 HomeWork 4
 * Group Member: Xudong Weng, Laiyong Mu
 *
 * This program is to display a rotating mobile with 4 levels of plates. Each plates has two child plates. The child plate is half size of its parent plate. We used recursive methods to draw plates from root to the bottom level. The detailed controls of the mobile are described as below.

 * Operations:
 * 	arrow up, down, left, right: select the panel. Selected panel showing with white frame.
 *  	+: show another row of leaf-plates, maximum is 4 levels.
 * 	-: kill the lowest row.
 * 	r: the slected plate rotate clockwise in larger steps.
 * 	R: the slected plate rotate counterclockwise in larger steps.
 * 	c: the slected plate rotating at some random constant angular speed (0.5 - 2.5, step size 0.02).
 * 	P: pause/play button for the rotation.
 * 	1: press number one close the window.
 *
 * Accompanied programs [raster.cxx, raster.h, raster-jpeg.cxx] are from "Paintdemo" provided by the instructor.

