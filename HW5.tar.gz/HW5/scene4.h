/*
 * Part of the program are modified from an online shader programing tuitorial
 * which was also used in class by the instructors. As required by the original
 * author, we provided its copyrights notice below:
 * 
 ********************************************
 * Copyright (C) 2010 Josh A. Beam
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *   1. Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *   2. Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <sys/time.h>
#include "GLee.h"
#include <GL/gl.h>
#include <GL/glext.h>
#include <GL/glut.h>
#include "cubeMap.h"

/* shader functions defined in shader.c */
extern void shaderAttachFromFile(GLuint, GLenum, const char *);
void RenderInitial(void);

static GLuint g_program, f_program;
static GLuint g_programCameraPositionLocation, f_programCameraPositionLocation; 
static GLuint g_programLightPositionLocation, f_programLightPositionLocation;
static GLuint g_programLightColorLocation, f_programLightColorLocation;
GLuint SnakeCylinder[37], CubeMap, vao;

static GLuint g_cylinderBufferId;
static unsigned int g_cylinderNumVertices;

static float g_cameraPosition[3];

#define NUM_LIGHTS 1
static float g_lightPosition[3] = {0, 0, 4};
static float g_lightColor[3];

const int floatsPerVertex = 6;
unsigned int size;      // size of the cylinder vertex buffer
float v[40][108];       // the vetex buffer for all triangle strip on the snake body
float originP[40][3];   // the cordinates of points on spline curve
int t0 = 0;    // the beging time of a motion cycle of snake
int t1 = 0;    // the current time during a motion cycle of snake

// cordinates of control points for the B spline
GLfloat ControlPoints1[7][3], ControlPoints2[7][3], ControlPoints[7][3];
GLfloat diskR;   // the radius of the snake body
float periodLength;   // the period of snake periodic motion

// cordinates for cubemap
float points[] = {
	  -10.0f,  10.0f, -10.0f,
	  -10.0f, -10.0f, -10.0f,
	   10.0f, -10.0f, -10.0f,
	   10.0f, -10.0f, -10.0f,
	   10.0f,  10.0f, -10.0f,
	  -10.0f,  10.0f, -10.0f,
	  
	  -10.0f, -10.0f,  10.0f,
	  -10.0f, -10.0f, -10.0f,
	  -10.0f,  10.0f, -10.0f,
	  -10.0f,  10.0f, -10.0f,
	  -10.0f,  10.0f,  10.0f,
	  -10.0f, -10.0f,  10.0f,
	  
	   10.0f, -10.0f, -10.0f,
	   10.0f, -10.0f,  10.0f,
	   10.0f,  10.0f,  10.0f,
	   10.0f,  10.0f,  10.0f,
	   10.0f,  10.0f, -10.0f,
	   10.0f, -10.0f, -10.0f,
	   
	  -10.0f, -10.0f,  10.0f,
	  -10.0f,  10.0f,  10.0f,
	   10.0f,  10.0f,  10.0f,
	   10.0f,  10.0f,  10.0f,
	   10.0f, -10.0f,  10.0f,
	  -10.0f, -10.0f,  10.0f,
	  
	  -10.0f,  10.0f, -10.0f,
	   10.0f,  10.0f, -10.0f,
	   10.0f,  10.0f,  10.0f,
	   10.0f,  10.0f,  10.0f,
	  -10.0f,  10.0f,  10.0f,
	  -10.0f,  10.0f, -10.0f,
	  
	  -10.0f, -10.0f, -10.0f,
	  -10.0f, -10.0f,  10.0f,
	   10.0f, -10.0f, -10.0f,
	   10.0f, -10.0f, -10.0f,
	  -10.0f, -10.0f,  10.0f,
	   10.0f, -10.0f,  10.0f
};


// read control points and other parameters from a file
// including each 7 control points at both begin and end motion phase
// also including snake body radius and anmation period
static void readControlPoints()
{
	int i,j;
	FILE* fp = fopen("./parameters.txt","r"); 
	if(fp == NULL)
		printf("no file found");
	for(i = 0; i < 14; i++)
	{
		for(j = 0; j < 3; j++)
		{
			if (i < 7)
				fscanf(fp,"%f", &ControlPoints1[i][j]);
			else
				fscanf(fp,"%f", &ControlPoints2[i-7][j]);
		}
		fscanf(fp,"\n");
	}
	fscanf(fp,"%f", &diskR);
	fscanf(fp,"%f", &periodLength);
	fclose(fp);
}

/* calculate the points in the B Spline curve */
static void BSpline(void){
	int pointNumber, i;    // the first knot in current control point group used to calculate B spline
	int NumSegments = 4;   // 7 control points generate 4 segments of B spline curve
	int interval = 10;      // the interval of points in each segment of B Spline curve
	
	
	for (pointNumber = 0; pointNumber < NumSegments; pointNumber++)
		{
			// for each segment of curve, draw interval number of divisions
			for(i = 0; i != interval; ++i) {
			
				// use the parametric time value 0 to 1 for this curve segment.
				float tao = (float)i/interval;
				// inverted tao value for faster calculation below
				float itao = 1.0 - tao;

				// calculate blending functions for cubic B spline
				float b0 = itao * itao * itao/6.0f;
				float b1 = (3 * tao * tao * tao - 6 * tao * tao + 4)/6.0f;
				float b2 = (-3 * tao * tao * tao + 3 * tao * tao + 3 * tao + 1)/6.0f;
				float b3 = tao * tao * tao/6.0f;

				// calculate the x,y and z of the curve point
				float x = b0 * ControlPoints[pointNumber + 0][0] +
						  b1 * ControlPoints[pointNumber + 1][0] +
						  b2 * ControlPoints[pointNumber + 2][0] +
						  b3 * ControlPoints[pointNumber + 3][0] ;

				float y = b0 * ControlPoints[pointNumber + 0][1] +
						  b1 * ControlPoints[pointNumber + 1][1] +
						  b2 * ControlPoints[pointNumber + 2][1] +
						  b3 * ControlPoints[pointNumber + 3][1] ;

				float z = b0 * ControlPoints[pointNumber + 0][2] +
						  b1 * ControlPoints[pointNumber + 1][2] +
						  b2 * ControlPoints[pointNumber + 2][2] +
						  b3 * ControlPoints[pointNumber + 3][2] ;

				// save the coordinates
				originP[pointNumber*interval + i][0] = x;
				originP[pointNumber*interval + i][1] = y;
				originP[pointNumber*interval + i][2] = z;
			}
	}
}

/* function to generate the vertices of trangles to draw cylinder*/
static void createCylinder(unsigned int divisions, int cylinderNum)
{
	unsigned int i, j;
	
	g_cylinderNumVertices = (divisions + 1) * 2;     // divisions indicate the number segments for each circle of the snake body cross section
	size = floatsPerVertex * g_cylinderNumVertices;  // the total size of vertices for each cylinder
	
	// ui, vi, wi are vectors describe the cross section of the snake body
	// distance, temporatory variable used to normalize vector
	GLfloat ui[3], vi[3], wi[3], distance;
	
	for (j = 0; j < 2; j++){
		// calculate the tagential vector at the point on the spline curve and normalize
		ui[0] = originP[cylinderNum+j+1][0] - originP[cylinderNum+j][0];
		ui[1] = originP[cylinderNum+j+1][1] - originP[cylinderNum+j][1];
		ui[2] = originP[cylinderNum+j+1][2] - originP[cylinderNum+j][2];
		distance = sqrt(ui[0] * ui[0] + ui[1] * ui[1] + ui[2] * ui[2]);
		ui[0] = ui[0] / distance;
		ui[1] = ui[1] / distance;
		ui[2] = ui[2] / distance;
			
		// calculate vector vi, which is orthognal to ui, and point to the highest points of snake body
		// solve A, vi = A.ui + (1-A).y, ui.vi = 0, y = [0,1,0]
		GLfloat coefficientA = ui[1]/(ui[1] - ui[0]*ui[0] - ui[1]*ui[1] - ui[2]*ui[2]);
		vi[0] = coefficientA*ui[0];
		vi[1] = coefficientA*ui[1] + 1 - coefficientA;
		vi[2] = coefficientA*ui[2];
		// normalize vi
		distance = sqrt(vi[0] * vi[0] + vi[1] * vi[1] + vi[2] * vi[2]);
		vi[0] = vi[0] / distance;
		vi[1] = vi[1] / distance;
		vi[2] = vi[2] / distance;
			
		// calculate vector wi, which is orthognal to both ui an vi;
		wi[0] = ui[1] * vi[2] - ui[2] * vi[1];
		wi[1] = ui[2] * vi[0] - ui[0] * vi[2];
		wi[2] = ui[0] * vi[1] - ui[1] * vi[0];
		
		for(i = 0; i <= divisions; ++i) {
		
			float r = ((M_PI * 2.0f) / (float)divisions) * (float)i;
			unsigned int index1 = i * 2 * floatsPerVertex;  // current body crossing section
			unsigned int index2 = index1 + floatsPerVertex; // next body crossing section
			GLfloat temp[3];

			/* vertex positions */
			// cordinates on the disk
			temp[0] = 0.0f;
			temp[1] = diskR*cosf(r);
			temp[2] = diskR*sinf(r);
			
			if (j == 0) { // points on current body crossing section
				// cordinates within new rotated axis depending on ui, vi, wi
				v[cylinderNum][index1 + 0] = temp[0] * ui[0] + temp[1] * vi[0] + temp[2] * wi[0];
				v[cylinderNum][index1 + 1] = temp[0] * ui[1] + temp[1] * vi[1] + temp[2] * wi[1];
				v[cylinderNum][index1 + 2] = temp[0] * ui[2] + temp[1] * vi[2] + temp[2] * wi[2];
				
				/* normals */
				v[cylinderNum][index1 + 3] = v[cylinderNum][index1 + 0];
				v[cylinderNum][index1 + 4] = v[cylinderNum][index1 + 1];
				v[cylinderNum][index1 + 5] = v[cylinderNum][index1 + 2];
								
				// cordinates after move origin to the points on the spline curve
				v[cylinderNum][index1 + 0] = v[cylinderNum][index1 + 0] + originP[cylinderNum][0];
				v[cylinderNum][index1 + 1] = v[cylinderNum][index1 + 1] + originP[cylinderNum][1];
				v[cylinderNum][index1 + 2] = v[cylinderNum][index1 + 2] + originP[cylinderNum][2];
			}
			if (j == 1) { // points on the next body crossing section
				// cordinates within new rotated axis depending on ui, vi, wi
				v[cylinderNum][index2 + 0] = temp[0] * ui[0] + temp[1] * vi[0] + temp[2] * wi[0];
				v[cylinderNum][index2 + 1] = temp[0] * ui[1] + temp[1] * vi[1] + temp[2] * wi[1];
				v[cylinderNum][index2 + 2] = temp[0] * ui[2] + temp[1] * vi[2] + temp[2] * wi[2];
				
				/* normals */
				v[cylinderNum][index2 + 3] = v[cylinderNum][index2 + 0];
				v[cylinderNum][index2 + 4] = v[cylinderNum][index2 + 1];
				v[cylinderNum][index2 + 5] = v[cylinderNum][index2 + 2];
				
				// cordinates after move origin to the points on the spline curve
				v[cylinderNum][index2 + 0] = v[cylinderNum][index2 + 0] + originP[cylinderNum+1][0];
				v[cylinderNum][index2 + 1] = v[cylinderNum][index2 + 1] + originP[cylinderNum+1][1];
				v[cylinderNum][index2 + 2] = v[cylinderNum][index2 + 2] + originP[cylinderNum+1][2];
				
			}
		}
	}
}

void sceneCycle(void);

void
sceneInit(void)
{
	GLint result;

	/* create program object and attach shaders */
	g_program = glCreateProgram();
	shaderAttachFromFile(g_program, GL_VERTEX_SHADER, "data/shader.vp");
	shaderAttachFromFile(g_program, GL_FRAGMENT_SHADER, "data/shader.fp");

	/* link the program and make sure that there were no errors */
	glLinkProgram(g_program);
	glGetProgramiv(g_program, GL_LINK_STATUS, &result);
	if(result == GL_FALSE) {
		GLint length;
		char *log;

		/* get the program info log */
		glGetProgramiv(g_program, GL_INFO_LOG_LENGTH, &length);
		log = (char *) malloc(length);
		glGetProgramInfoLog(g_program, length, &result, log);

		/* print an error message and the info log */
		fprintf(stderr, "sceneInit(): Program linking failed: %s\n", log);
		free(log);

		/* delete the program */
		//Dettach and delete shaders
		glDeleteProgram(g_program);
		g_program = 0;
	}

	/* get uniform locations */
	g_programCameraPositionLocation = glGetUniformLocation(g_program, "cameraPosition");
	g_programLightPositionLocation = glGetUniformLocation(g_program, "lightPosition");
	g_programLightColorLocation = glGetUniformLocation(g_program, "lightColor");

	/////////////
	/* create program object (cube map) and attach shaders */
	f_program = glCreateProgram();
	shaderAttachFromFile(f_program, GL_VERTEX_SHADER, "data/shader.vp2");
	shaderAttachFromFile(f_program, GL_FRAGMENT_SHADER, "data/shader.fp2");

	/* link the program and make sure that there were no errors */
	glLinkProgram(f_program);
	glGetProgramiv(f_program, GL_LINK_STATUS, &result);
	if(result == GL_FALSE) {
		GLint length;
		char *log;

		/* get the program info log */
		glGetProgramiv(f_program, GL_INFO_LOG_LENGTH, &length);
		log = (char *) malloc(length);
		glGetProgramInfoLog(f_program, length, &result, log);

		/* print an error message and the info log */
		fprintf(stderr, "sceneInit(): Program linking failed: %s\n", log);
		free(log);

		/* delete the program */
		// Dettach and delete shaders
		glDeleteProgram(f_program);
		f_program = 0;
	}

	/* get uniform locations */
	f_programCameraPositionLocation = glGetUniformLocation(f_program, "cameraPosition");
	f_programLightPositionLocation = glGetUniformLocation(f_program, "lightPosition");
	f_programLightColorLocation = glGetUniformLocation(f_program, "lightColor");

	///////////
	
	/* set up red lights */
	g_lightColor[0] = 1.0f; g_lightColor[1] = 0.0f; g_lightColor[2] = 0.0f;
	
	/* create cubemap Textures */
	CubeMapTex();
	
	/* create cylinder */
	int k, h;
	// initiate Control points
	readControlPoints();
	for (k = 0; k < 7; k++) {
		for (h = 0; h < 3; h++) 
			ControlPoints[k][h] = ControlPoints1[k][h];
	}
	BSpline();
	
	int i;
			
	for (i = 0; i < 38; i++)
		createCylinder(8, i);
		
	sceneCycle();

	/* setup camera */
	g_cameraPosition[0] = 0.0f;
	g_cameraPosition[1] = 0.0f;
	g_cameraPosition[2] = 16.0f;
	glLoadIdentity();
	glTranslatef(-g_cameraPosition[0], -g_cameraPosition[1], -g_cameraPosition[2]);
	
	
}

void cyclinderRender()//(float *vertexInput) 
{
	// /* create vertex buffer */
	// glDisable(GL_TEXTURE_2D);
	// glGenBuffers(1, &g_cylinderBufferId);
	// glBindBuffer(GL_ARRAY_BUFFER, g_cylinderBufferId);
	// glBufferData(GL_ARRAY_BUFFER, sizeof(float) * size, vertexInput, GL_STATIC_DRAW);
	
	// /* enable arrays */
	// glEnableClientState(GL_VERTEX_ARRAY);
	// glEnableClientState(GL_NORMAL_ARRAY);
	// /* set pointers */
	// glVertexPointer(3, GL_FLOAT, sizeof(float) * floatsPerVertex, 0);
	// glNormalPointer(GL_FLOAT, sizeof(float) * floatsPerVertex, (const GLvoid *)(sizeof(float) * 3));

	// /* render the cylinder */
	// glDrawArrays(GL_TRIANGLE_STRIP, 0, g_cylinderNumVertices);
	// glBindBuffer(GL_ARRAY_BUFFER, 0);
	
	/////////////////
	/* render the snake body */
	glEnable(GL_DEPTH_TEST);
	int i;
	for (i = 0; i < 38; i++)
	{
		glEnable(GL_CULL_FACE);
		glBindTexture(GL_TEXTURE_CUBE_MAP, texture);
		glUseProgram(g_program);
		glUniform3fv(g_programCameraPositionLocation, 1, g_cameraPosition);
		glUniform3fv(g_programLightPositionLocation, 1, g_lightPosition);
		glUniform3fv(g_programLightColorLocation, 1, g_lightColor);
		glBindBuffer(GL_ARRAY_BUFFER, SnakeCylinder[i]);
		/* enable arrays */
		glEnableClientState(GL_VERTEX_ARRAY);
		glEnableClientState(GL_NORMAL_ARRAY);
		/* set pointers */
		glVertexPointer(3, GL_FLOAT, sizeof(float) * floatsPerVertex, 0);
		glNormalPointer(GL_FLOAT, sizeof(float) * floatsPerVertex, (const GLvoid *)(sizeof(float) * 3));
		glDrawArrays(GL_TRIANGLE_STRIP, 0, g_cylinderNumVertices);
	
		glDisableClientState(GL_VERTEX_ARRAY);
		glDisableClientState(GL_NORMAL_ARRAY);
		glBindBuffer(GL_ARRAY_BUFFER, 0);
		glUseProgram(0);
		glBindTexture(GL_TEXTURE_CUBE_MAP, 0);
	}
	glDisable(GL_DEPTH_TEST);
	////////////////
	
}	

void cubeMapRender() 
{
	/* glDepthMask (GL_FALSE);
	glEnable(GL_TEXTURE_2D);
	
	glGenBuffers (1, &CubeMap);
	glBindBuffer (GL_ARRAY_BUFFER, CubeMap);
	glBufferData (GL_ARRAY_BUFFER, 3 * 36 * sizeof (float), &points, GL_STATIC_DRAW);

	GLuint vao;
	glGenVertexArrays (1, &vao);
	glBindVertexArray (vao);
	glEnableVertexAttribArray (0);
	glBindBuffer (GL_ARRAY_BUFFER, CubeMap);
	glVertexAttribPointer (0, 3, GL_FLOAT, GL_FALSE, 0, NULL);

	glActiveTexture (GL_TEXTURE0);
	glBindTexture (GL_TEXTURE_CUBE_MAP, texture);
	glBindVertexArray (vao);
	glDrawArrays (GL_TRIANGLES, 0, 36);
	glDepthMask (GL_TRUE);
	glBindBuffer(GL_ARRAY_BUFFER, 0); */
	
	////////////////////////////
	/* render cube map */
	
	glDisable(GL_DEPTH_TEST);
	//glDepthMask (GL_FALSE);
	
	// cubemap buffer
	
	glGenBuffers (1, &CubeMap);
	glBindBuffer (GL_ARRAY_BUFFER, CubeMap);
	glBufferData (GL_ARRAY_BUFFER, 3 * 36 * sizeof (float), &points, GL_STATIC_DRAW);
	
	glUseProgram(f_program);
	glGenVertexArrays (1, &vao);
	glBindVertexArray (vao);
	glEnableVertexAttribArray (0);
	glBindBuffer (GL_ARRAY_BUFFER, CubeMap);
	glVertexAttribPointer (0, 3, GL_FLOAT, GL_FALSE, 0, NULL);
	glActiveTexture (GL_TEXTURE0);   //?
	glBindTexture(GL_TEXTURE_CUBE_MAP, texture);
    glUniform3fv(f_programCameraPositionLocation, 1, g_cameraPosition);
	glBindVertexArray (vao);
	glDrawArrays (GL_TRIANGLES, 0, 36);
	glDisableVertexAttribArray(0);
	glBindBuffer(GL_ARRAY_BUFFER, 0);
    glUseProgram(0);
    glBindTexture(GL_TEXTURE_CUBE_MAP, 0);
	
	
	///////////////////////////
	
}

void RenderInitial(void)
{	
	glUniform3fv(f_programCameraPositionLocation, 1, g_cameraPosition);
	glUniform3fv(g_programCameraPositionLocation, 1, g_cameraPosition);
	glUniform3fv(g_programLightPositionLocation, 1, g_lightPosition);
	glUniform3fv(g_programLightColorLocation, 1, g_lightColor);
	
	/* // cubemap buffer
	glGenBuffers (1, &CubeMap);
	glBindBuffer (GL_ARRAY_BUFFER, CubeMap);
	glBufferData (GL_ARRAY_BUFFER, 3 * 36 * sizeof (float), &points, GL_STATIC_DRAW);
	
	glGenVertexArrays (1, &vao);
	glBindVertexArray (vao);
	glEnableVertexAttribArray (0);
	glBindBuffer (GL_ARRAY_BUFFER, CubeMap);
	//glVertexAttribPointer (0, 3, GL_FLOAT, GL_FALSE, 0, NULL);
	glBindBuffer(GL_ARRAY_BUFFER, 0); */

	// snake body cylinder buffer
	float *vet;
	int i;
	for (i = 0; i < 38; i++)
	{
		vet = v[i];
		glGenBuffers(1, &SnakeCylinder[i]);
		glBindBuffer(GL_ARRAY_BUFFER, SnakeCylinder[i]);
		glBufferData(GL_ARRAY_BUFFER, sizeof(float) * size, vet, GL_STATIC_DRAW);
	}
	glBindBuffer(GL_ARRAY_BUFFER, 0);
}

void
sceneRender(void)
{
	RenderInitial();
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
			
	/* render cubemap */
	// glUseProgram(f_program);
	// glUniform3fv(f_programCameraPositionLocation, 1, g_cameraPosition);
	// glUniform3fv(f_programLightPositionLocation, 1, g_lightPosition);
	// glUniform3fv(f_programLightColorLocation, 1, g_lightColor);
	
	cubeMapRender();
	cyclinderRender();
	
	
	/* disable program */
	//glUseProgram(0);
		
	/* render snake body */
	// glUseProgram(g_program);
	// glUniform3fv(g_programCameraPositionLocation, 1, g_cameraPosition);
	// glUniform3fv(g_programLightPositionLocation, 1, g_lightPosition);
	// glUniform3fv(g_programLightColorLocation, 1, g_lightColor);
	
	int i;
	//for (i = 0; i < 38; i++)
		//cyclinderRender(v[i]);
	
	/* disable program */
	//glUseProgram(0);
	
	
	//int i;
	/* render control points for B-Spline curve */
	for(i = 0; i < 7; ++i) {
		/* render sphere with control points */
		glPushMatrix();
		glTranslatef(ControlPoints[i][0], ControlPoints[i][1], ControlPoints[i][2]);
		GLfloat pointColor[3] = {1.0f, 1.0f, 1.0f};
		glColor3fv(pointColor);
		glutSolidSphere(0.08, 36, 36);
		glPopMatrix();
	}
	
	glutSwapBuffers();
}

static unsigned int
getTicks(void)
{
	struct timeval t;
	gettimeofday(&t, NULL);
	return (t.tv_sec * 1000) + (t.tv_usec / 1000);
}

void
sceneCycle(void)
{
	
	int i, k, h;
		
	float SnakeTime = 0.0;      // indicate the time of snake motion period
	
	/* update the control point positions */
	if (pauseLable == 0) {
	
		if (t0 == 0) 
			t0 = getTicks();
		t1 = getTicks();
		
		if (t1 >= t0 && (t1 < t0 + periodLength)) 
			SnakeTime = (float) (t1 - t0) / periodLength;
		if ((t1 >= (t0 + periodLength)) && t1 <= (t0 + 2 * periodLength)) 
			SnakeTime = (float)(t0 - t1 + 2 * periodLength) / periodLength;
		if (t1 > (t0 + 2 * periodLength))
			t0 = 0;
		
		for (k = 0; k < 7; k++){
			for (h = 0; h < 3; h++)
				ControlPoints[k][h] = (1 - SnakeTime) * ControlPoints1[k][h] + SnakeTime * ControlPoints2[k][h];
		}
		BSpline();
		for (i = 0; i < 38; i++)
			createCylinder(8, i);
	}
	glutPostRedisplay();
}
