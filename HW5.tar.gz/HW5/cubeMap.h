extern ByteRaster *read_jpeg_image(const char *filename);
static ByteRaster *gimage[6];            // pixel buffer for jpeg picture
void ReadInFile();         		        // read jpeg file to buffer
static char *infile[6];                // names of the pictures' file
GLuint texture;

static void CubeMapTex()
{
	ReadInFile();
	
	glGenTextures(1, &texture);
	glBindTexture(GL_TEXTURE_CUBE_MAP, texture);
	
	glTexParameteri (GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_R, GL_CLAMP_TO_EDGE);
	glTexParameteri (GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri (GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glTexParameteri (GL_TEXTURE_CUBE_MAP, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri (GL_TEXTURE_CUBE_MAP, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	
	glTexImage2D(GL_TEXTURE_CUBE_MAP_POSITIVE_X, 0, GL_RGB, 600, 600, 0, GL_RGB, GL_UNSIGNED_BYTE, gimage[1]->data);
	glTexImage2D(GL_TEXTURE_CUBE_MAP_NEGATIVE_X, 0, GL_RGB, 600, 600, 0, GL_RGB, GL_UNSIGNED_BYTE, gimage[3]->data);
	glTexImage2D(GL_TEXTURE_CUBE_MAP_POSITIVE_Y, 0, GL_RGB, 600, 600, 0, GL_RGB, GL_UNSIGNED_BYTE, gimage[4]->data);
	glTexImage2D(GL_TEXTURE_CUBE_MAP_NEGATIVE_Y, 0, GL_RGB, 600, 600, 0, GL_RGB, GL_UNSIGNED_BYTE, gimage[5]->data);
	glTexImage2D(GL_TEXTURE_CUBE_MAP_POSITIVE_Z, 0, GL_RGB, 600, 600, 0, GL_RGB, GL_UNSIGNED_BYTE, gimage[0]->data);
	glTexImage2D(GL_TEXTURE_CUBE_MAP_NEGATIVE_Z, 0, GL_RGB, 600, 600, 0, GL_RGB, GL_UNSIGNED_BYTE, gimage[2]->data);

}

void ReadInFile(){
	infile[0] = "m01.jpg";
	infile[1] = "m02.jpg";
	infile[2] = "m03.jpg";
	infile[3] = "m04.jpg";
	infile[4] = "m05.jpg";
	infile[5] = "m06.jpg";
	
	int i;
	for (i = 0; i < 6; i++)
		gimage[i] = read_jpeg_image(infile[i]);
}